#ifndef _KEY_H_
#define _KEY_H_
#include "main.h"

#define KEY_1()    	((GPIOB->IDR &(1<<8)) >> 8)
#define KEY_2()  	((GPIOB->IDR &(1<<9)) >> 9)

void Key_Init(void);
u8 Get_Key_Val(void);
#endif
