#ifndef _LED_H_
#define _LED_H_

#define LED1(x)	x?(GPIOC->ODR &= ~(0x01<<(1*0))):(GPIOC->ODR |= (0x01<<(1*0)))
#define LED2(x)	x?(GPIOC->ODR &= ~(0x01<<(1*1))):(GPIOC->ODR |= (0x01<<(1*1)))
#define LED3(x)	x?(GPIOC->ODR &= ~(0x01<<(1*2))):(GPIOC->ODR |= (0x01<<(1*2)))

#define Light(x)	x?(GPIOC->ODR |= (0x01<<(1*7))):(GPIOC->ODR &= ~(0x01<<(1*7)))
#define RGB_RED(x)	x?(GPIOC->ODR &= ~(0x01<<(1*8))):(GPIOC->ODR |= (0x01<<(1*8)))
#define RGB_GREEN(x)	x?(GPIOC->ODR &= ~(0x01<<(1*9))):(GPIOC->ODR |= (0x01<<(1*9)))
#define RGB_BLUE(x)	x?(GPIOA->ODR &= ~(0x01<<(1*8))):(GPIOA->ODR |= (0x01<<(1*8)))

#define LED1_TOGGLE() GPIOC->ODR ^= (0X01 << 1*0)
#define LED2_TOGGLE() GPIOC->ODR ^= (0X01 << 1*1)
#define LED3_TOGGLE() GPIOC->ODR ^= (0X01 << 1*2)
#define Light_TOGGLE() GPIOC->ODR ^= (0X01 << 1*7)
#define RGB_RED_TOGGLE() GPIOC->ODR ^= (0X01 << 1*8)
#define RGB_GREEN_TOGGLE() GPIOC->ODR ^= (0X01 << 1*9)
#define RGB_BLUE_TOGGLE() GPIOA->ODR ^= (0X01 << 1*8)

//��������
void LED_GPIO_INIT(void);
void LED_ALL_ON(void);
void LED_ALL_OFF(void);
void Light_Init(void);
void LED_RGB_Init(void);
void RGB_ON(void);
void RGB_OFF(void);

#endif
