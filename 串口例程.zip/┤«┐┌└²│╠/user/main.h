#ifndef _MAIN_H_
#define _MAIN_H_

#include "stm32f10x.h"
#include "sys_tick.h"
#include "nvic.h"
#include "led.h"
#include "key.h"
#include "usart.h"
#include "stdio.h"
#include <string.h>

#endif

