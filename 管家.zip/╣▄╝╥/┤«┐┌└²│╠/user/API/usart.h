#ifndef _USART_H_
#define _USART_H_

#include "main.h"
#include "stdio.h"
void USART_Config(void);
void Usart_echo(void);
void PrintCom(USART_TypeDef* USARTx, uint8_t *Data);
u8 Resive_Data(void);
void RCC_Configuration(void);
#endif

