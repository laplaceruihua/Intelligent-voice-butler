#include "stm32f10x.h"
#include "sys_tick.h"
#include "nvic.h"

vu32 RunTime=0;
vu32 sysTiming=0;


void Delay_init(void)
{
  SysTick_Config(72000-1);
}


void SysTick_Handler(void)
{
	
  RunTime++;
	sysTiming++;

}

void Delay_ms(u32 time)
{
	u32 temp;
	temp = RunTime+time;
	while((temp - RunTime) != 0);
}

