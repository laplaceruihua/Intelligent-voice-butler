#ifndef _SYS_TICK_H_
#define _SYS_TICK_H_
#include "stm32f10x.h"



extern vu32 Run2Time ;
extern vu32 sysTiming ;

void Delay_init(void);
void Delay_ms(u32 time);

#endif
