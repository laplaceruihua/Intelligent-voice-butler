#ifndef _FATFS_TEST_H_
#define _FATFS_TEST_H_
#include "main.h"

void SD_test(void);
#endif
