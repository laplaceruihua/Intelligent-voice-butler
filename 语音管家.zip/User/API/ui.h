#ifndef _UI_H_
#define _UI_H_


#include "GUI.h"


void UI_Task(void);
#endif
