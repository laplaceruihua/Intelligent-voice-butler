#include "ui.h"
#include "tu1.h"


void UI_Task(void)
{
	Lcd_Show_Photo(0,0,100,124,gImage_tu);

}