#ifndef _USART_H_
#define _USART_H_

#include "main.h"
#include <string.h>
void  USART_Config(void);
void PrintCom(USART_TypeDef* USARTx, uint8_t *Data);

u8 Resive_data(char *buf);

#endif
